"""Compare Science articles with and without a print headline."""

import csv
import json
import statistics
from pathlib import Path
from typing import Any


MODULE_HOME = Path(__file__).resolve().parent.parent
DATA_PATH = MODULE_HOME / "data" / "provided" / "articles.json"
OUTPUT_PATH = Path(__file__).resolve().parent / "science_print_headline_results.csv"


def read_articles() -> list[dict[str, Any]]:
    with DATA_PATH.open(encoding="utf-8") as file:
        articles = json.load(file)
    return articles


def is_science(article: dict[str, Any]) -> bool:
    return article["section_name"] == "Science"


def has_print_headline(article: dict[str, Any]) -> bool:
    return article["headline"]["print_headline"] != ""


def summarize(articles: list[dict[str, Any]]) -> dict[str, Any]:
    lengths = [article["word_count"] for article in articles]
    return {
        "count": len(articles),
        "median_word_count": statistics.median(lengths),
        "mean_word_count": statistics.mean(lengths),
        "zero_word_count": sum(length == 0 for length in lengths),
    }


def main() -> None:
    # Iteration and transformation: the two list comprehensions visit every record
    # and retain only Science records, then split them by print-headline presence.
    articles = read_articles()
    science_articles = [article for article in articles if is_science(article)]
    with_print = [article for article in science_articles if has_print_headline(article)]
    without_print = [article for article in science_articles if not has_print_headline(article)]

    # Validation: these invariants catch a wrong field, a partial read, or a bad split.
    assert len(articles) == 1010
    assert len(science_articles) == 675
    assert len(with_print) + len(without_print) == len(science_articles)
    assert all(article["section_name"] == "Science" for article in science_articles)
    assert all(article["headline"]["print_headline"] != "" for article in with_print)
    assert all(article["headline"]["print_headline"] == "" for article in without_print)

    summaries = {
        "with_print_headline": summarize(with_print),
        "without_print_headline": summarize(without_print),
    }
    print(f"records read: {len(articles)}")
    print(f"Science records: {len(science_articles)}")
    for label, summary in summaries.items():
        print(label, summary)

    # Selection: retain only fields needed to compare and trace each row.
    with OUTPUT_PATH.open("w", newline="", encoding="utf-8") as file:
        fieldnames = ["group", "headline", "print_headline", "word_count", "pub_date", "web_url"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for group, records in (("with", with_print), ("without", without_print)):
            for article in records:
                writer.writerow(
                    {
                        "group": group,
                        "headline": article["headline"]["main"],
                        "print_headline": article["headline"]["print_headline"],
                        "word_count": article["word_count"],
                        "pub_date": article["pub_date"],
                        "web_url": article["web_url"],
                    }
                )
    print(f"rows written: {len(with_print) + len(without_print)}")


if __name__ == "__main__":
    main()
