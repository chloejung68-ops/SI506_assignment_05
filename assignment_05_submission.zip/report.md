# Assignment 05 Report

## 1.0 Your question

Do Science articles with a nonempty `headline["print_headline"]` have a different median
`word_count` from Science articles whose print headline is empty? This requires filtering by
`section_name`, splitting by the print-headline condition, and aggregating the two groups with
medians. It is worth asking because a print headline may be a shortened editorial label, and the
comparison tests whether its presence is associated with a different kind of article length.

## 2.0 The collection, and what it is not

The file contains 1,010 New York Times article metadata records, not article text. Each record has
fields describing a headline, keywords, author, date, section, length, and source URL. The records
come from one query: the Science news desk, the keyword `Research`, and the publication window from
2023-08-19 through 2026-07-30. The section values are lopsided: Science has 675 records, Health
329, U.S. 3, Climate 2, and Times Insider 1.

My filter relies on `section_name`, and the subset is the 675 records where it equals `Science`.
Within that subset, 624 have a nonempty `headline["print_headline"]` and 51 have the empty string.
The collection is not “the news,” all science journalism, or all New York Times science coverage.
For example, it cannot answer how much attention the Times gave a treatment across all desks and
keywords. A health reporter using this file to assess treatment coverage could miss Health records
because the query is fixed to the Science desk and `Research` keyword, and could not tell from an
individual record alone that those records were excluded. A reader might wrongly assume that the
675 Science records represent the whole newspaper's science coverage.

## 3.0 The filter, designed and defended

In plain language, I keep records whose `section_name` is exactly `Science`. This specifies the
editorial section I want and drops the 335 records from every other section. In Python it is:

```python
science_articles = [
    article for article in articles
    if article["section_name"] == "Science"
]
```

I then classify every retained record using the real nested field
`article["headline"]["print_headline"]`: a nonempty string belongs to the “with print headline”
group, and the empty string belongs to the “without” group. This is an exhaustive two-way split,
not a test for `None`, because this data represents absence as `""`. It keeps 624 in the first
group and 51 in the second, so the Science filter keeps 675 and drops 335; the split drops no
Science records from the comparison.

The condition discriminates: `Sports` would match zero records, while `Research` in a keyword
list matches all 1,010 and would not filter. `subsection_name` is present but usable for only 8
records, and `Climate` occurs only twice. I checked the actual section counts and the print-headline
counts before interpreting the result, so my condition is neither an absent value nor a nearly
universal or extremely rare filter.

## 4.0 Data quality and coverage

The gap directly bearing on my comparison is `headline["print_headline"]`: it is
optional-and-fine, not an error. It is empty for 86 of 1,010 records, including 51 of the 675
Science records. Thus the “without” result describes only 7.6% of the whole collection, while the
“with” result describes 61.8%; both describe all of the Science subset. I did not replace empty
values or treat them as missing rows, because absence is the editorial fact being compared.

The medians are 776.5 words with a print headline and 838 words without one. The single record with
`word_count == 0` is in the without group. Recomputing that group's median after excluding it gives
838 words, the same result; including it gives 838 as well. The unchanged median says this one
record does not move this particular middle value in a group of 51. It does not show that the zero
record is sound, nor that zero-length records would never affect a mean or a smaller subset. I
deliberately settled that a nonempty print headline means exactly a string other than `""`; the
source does not provide a stronger quality judgment.

## 5.0 Results and verification

The answer is that the group without a print headline has a median 61.5 words longer than the group
with one (838 versus 776.5). The code also reports means: 815.29 without and 932.99 with, but I use
the medians as the main answer because the maximum lengths are uneven (3,771 with and 1,715
without). The pipeline reads every record in `read_articles`, iterates in the two comprehensions,
transforms by filtering and splitting, and validates with assertions for population, section, and
exhaustive membership before summarizing.

I verified every cited count and median against the shipped JSON. The independent checks are
documented in `verification.md`: a separate counting route reconciled 1,010 = 675 + 335 and
675 = 624 + 51; direct scans found the 86 empty print headlines and the one zero length; and
named records were opened in the source to confirm nested headline fields, word counts, and URLs.
The sorted middle values were also recomputed directly from the source: 776 and 777 produce 776.5,
while the middle values for the 51-record group produce 838.

## 6.0 What your result keeps and drops

Each output CSV row keeps a group label, main headline, print headline, numeric `word_count`,
`pub_date`, and `web_url`. I drop abstract, byline, document type, keywords, news desk, section,
snippet, source, subsection, and type of material because they are not needed for this comparison.
The output retains the URL, so a reader can find the exact source article again in the JSON or on
the web. The URL works as an identifier because it is a record-specific address, whereas a headline
or word count can be shared or changed and cannot guarantee one record.

## 7.0 AI critique and verification log

The collaboration prompt was: “Write a readable Python pipeline for this question: compare median
`word_count` for Science NYT articles with and without a nonempty nested
`headline["print_headline"]`; read `data/provided/articles.json`, preserve `web_url`, validate the
counts, and write a CSV.” The generated draft used the correct `section_name`, nested headline
path, numeric word count, and empty-string test. I accepted those schema decisions, but corrected
the draft by adding assertions that the whole 1,010-record population was read and that the two
groups reconcile exactly. I also added the URL to make rows traceable. The independent source checks
are in `verification.md`, not repeated here. The prompt did not specify whether to report means as
well as medians or which fields to export; the pipeline decided to report both but use medians for
the question and to export only comparison and traceability fields.

## 8.0 Assumptions and limits

I assume `word_count` is a useful numeric proxy for article length, although it is metadata rather
than a measurement I independently audited. I also assume the source's empty print headline means
“no print headline supplied,” not “the article was unsuitable for print.” The comparison is not
causal: it cannot show that a print headline causes a length difference.

The result would mislead a reader who generalizes the 51-record without group to all NYT articles;
it is only 7.6% of this query's collection. It also cannot answer coverage questions outside the
Science desk, `Research` keyword, and date window. I treated `subsection_name` as out of scope because
only 8 records have a usable value, so it would not help answer this question and would describe a
misleadingly tiny slice.

## 9.0 Reflection

The hardest part was making “has a print headline” precise: I had to use the nested field and the
data's empty-string convention rather than guessing that missing meant `None`. Running the code
showed that the groups were 624 and 51 and that the zero-word record was in the smaller group;
reading the schema alone did not reveal those placements. The number I had to verify rather than
trust from the generated draft was the 776.5 median, which required sorting the 624 source values
and checking the two middle values.
