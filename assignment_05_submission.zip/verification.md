# Assignment 05 Verification Log

## 1.0 Independent checks against the source

I loaded `modules/module_05/data/provided/articles.json` independently of the pipeline's printed
summary and counted with explicit loops:

```python
total = science = with_print = without_print = 0
empty_print_whole_file = zero_lengths = 0
for article in articles:
    total += 1
    if article["headline"]["print_headline"] == "":
        empty_print_whole_file += 1
    if article["word_count"] == 0:
        zero_lengths += 1
    if article["section_name"] == "Science":
        science += 1
        if article["headline"]["print_headline"] == "":
            without_print += 1
        else:
            with_print += 1
```

This produced 1,010 total, 675 Science, 624 with a print headline, and 51 without. The
reconciliations are 675 + 335 = 1,010 and 624 + 51 = 675. A second direct scan found 86 empty
print headlines in the whole file and exactly one zero `word_count`; that zero is in the 51-record
without group.

For the medians, I built fresh lists directly from the JSON, sorted each list, and inspected the
middle values. The 624-record list has middle values 776 and 777, so its median is 776.5. The
51-record list has median 838. Removing its zero-length record leaves the median at 838. These
checks do not rely on the pipeline's output CSV.

Named source spot-checks also confirmed the nested fields and traceability. With a print headline,
`Health Care Agency Discontinues Dozens of Active Research Awards` has print headline `Health Care
Agency Stops Dozens of Research Grants`, `word_count` 930, and a URL ending in
`health-research-funding-ahrq.html`. Without one, `'This Is Very Strange': Ancient Smallpox May
Have Been Less Deadly` has `print_headline == ""` and `word_count` 1,423. A third without one,
`Testosterone Can Affect Behavior. What Could That Mean for the Military?`, has `word_count` 1,680.

## 2.0 Collaboration and critique

Prompt given to Codex: “Write a readable Python pipeline for this question: compare median
`word_count` for Science NYT articles with and without a nonempty nested
`headline["print_headline"]`; read `data/provided/articles.json`, preserve `web_url`, validate the
counts, and write a CSV.”

The key generated approach was:

```python
science_articles = [a for a in articles if a["section_name"] == "Science"]
with_print = [a for a in science_articles
              if a["headline"]["print_headline"] != ""]
```

I checked that it uses `section_name`, reaches `headline["print_headline"]` at the correct nesting
level, compares the integer `word_count` numerically, and treats `""` as absence. I accepted the
filter and corrected the draft to add whole-file and reconciliation assertions, the zero-record
check, and `web_url` in the selected output. The explicit counts, sorted middle values, and named
spot-checks above verified the corrected result against the source rather than treating a clean
run as proof. The prompt left the output-field choice open; I decided to keep the comparison fields
plus `pub_date` and `web_url` so every row remains traceable.
